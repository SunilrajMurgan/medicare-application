import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { saveHealthQuery, getUserHealthQueries } from '../../services/aiService';
import { HealthQuery } from '../../types';

const ChatInterface: React.FC = () => {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState<{
    id: string;
    content: string;
    sender: 'user' | 'assistant';
    timestamp: Date;
  }[]>([
    {
      id: 'welcome',
      content: "Hello! I'm your health assistant. How can I help you today? I can answer questions about common health concerns like fever, cold, or headache.",
      sender: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [pastQueries, setPastQueries] = useState<HealthQuery[]>([]);

  useEffect(() => {
    // Scroll to bottom whenever messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (user) {
      // Load past queries
      const queries = getUserHealthQueries(user.id);
      setPastQueries(queries);
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!query.trim() || !user) return;
    
    const trimmedQuery = query.trim();
    setQuery('');
    
    // Add user message
    const userMessage = {
      id: Date.now().toString(),
      content: trimmedQuery,
      sender: 'user' as const,
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);
    
    try {
      // Get response from health assistant service
      const healthQuery = await saveHealthQuery(trimmedQuery, 'other', user.id);
      
      // Add assistant message
      const assistantMessage = {
        id: `response-${Date.now()}`,
        content: healthQuery.answer || 'Sorry, I could not process your request.',
        sender: 'assistant' as const,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, assistantMessage]);
      
      // Update past queries
      setPastQueries((prev) => [healthQuery, ...prev]);
    } catch (error) {
      // Add error message
      const errorMessage = {
        id: `error-${Date.now()}`,
        content: 'Sorry, there was an error processing your request. Please try again later.',
        sender: 'assistant' as const,
        timestamp: new Date(),
      };
      
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePastQueryClick = (query: HealthQuery) => {
    // Add past query to the chat
    const userMessage = {
      id: Date.now().toString(),
      content: query.question,
      sender: 'user' as const,
      timestamp: new Date(),
    };
    
    const assistantMessage = {
      id: `response-${Date.now()}`,
      content: query.answer || 'No response available.',
      sender: 'assistant' as const,
      timestamp: new Date(query.createdAt),
    };
    
    setMessages((prev) => [...prev, userMessage, assistantMessage]);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 h-[calc(100vh-12rem)]">
      {/* Chat section */}
      <div className="flex-1 flex flex-col bg-white rounded-lg shadow overflow-hidden">
        <div className="bg-primary-600 text-white px-4 py-3 flex items-center">
          <Bot className="mr-2" size={20} />
          <h2 className="font-semibold">Health Assistant</h2>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${
                message.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.sender === 'user'
                    ? 'bg-primary-500 text-white rounded-br-none'
                    : 'bg-gray-100 text-gray-800 rounded-bl-none'
                }`}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs mt-1 opacity-70">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="max-w-[80%] bg-gray-100 rounded-lg px-4 py-2 rounded-bl-none">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={handleSubmit} className="border-t p-4">
          <div className="flex items-center">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your health question..."
              className="flex-1 border border-gray-300 rounded-l-lg py-2 px-3 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="bg-primary-600 text-white p-2 rounded-r-lg enabled:hover:bg-primary-700 disabled:opacity-50"
            >
              <Send size={20} />
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Note: This is an AI assistant and not a substitute for professional medical advice. 
            Always consult a healthcare provider for medical concerns.
          </p>
        </form>
      </div>
      
      {/* Previous queries */}
      <div className="w-full lg:w-72 bg-white rounded-lg shadow overflow-hidden flex flex-col">
        <div className="bg-gray-100 px-4 py-3">
          <h2 className="font-semibold text-gray-700">Previous Conversations</h2>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
          {pastQueries.length > 0 ? (
            <ul className="space-y-2">
              {pastQueries.map((query) => (
                <li key={query.id}>
                  <button
                    onClick={() => handlePastQueryClick(query)}
                    className="w-full text-left p-2 hover:bg-gray-50 rounded text-sm"
                  >
                    <p className="font-medium truncate">{query.question}</p>
                    <p className="text-xs text-gray-500">
                      {new Date(query.createdAt).toLocaleDateString()}
                    </p>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-gray-500 p-4 text-center">
              No previous conversations yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;