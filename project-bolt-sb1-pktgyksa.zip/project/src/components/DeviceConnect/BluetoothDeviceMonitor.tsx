import React, { useState, useEffect } from 'react';
import { Heart, Activity, Bluetooth, AlertCircle } from 'lucide-react';
import { bluetoothService } from '../../services/deviceService';

const BluetoothDeviceMonitor: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [heartRate, setHeartRate] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isAvailable, setIsAvailable] = useState(false);

  useEffect(() => {
    setIsAvailable(bluetoothService.isAvailable);

    const unsubscribe = bluetoothService.subscribe(state => {
      setIsConnected(state.connected);
      setHeartRate(state.heartRate);
      setError(state.error);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const connectDevice = async () => {
    try {
      await bluetoothService.connectToHeartRateMonitor();
    } catch (err) {
      setError('Failed to connect to heart rate monitor');
    }
  };

  const disconnectDevice = async () => {
    try {
      await bluetoothService.disconnect();
    } catch (err) {
      setError('Failed to disconnect from heart rate monitor');
    }
  };

  const getHeartRateCategory = (rate: number | null): {
    category: 'normal' | 'elevated' | 'high' | 'unknown';
    color: string;
    message: string;
  } => {
    if (rate === null) {
      return {
        category: 'unknown',
        color: 'gray',
        message: 'No data available',
      };
    }

    if (rate < 60) {
      return {
        category: 'normal',
        color: 'blue',
        message: 'Below average resting heart rate',
      };
    }

    if (rate >= 60 && rate <= 100) {
      return {
        category: 'normal',
        color: 'green',
        message: 'Normal resting heart rate',
      };
    }

    if (rate > 100 && rate <= 120) {
      return {
        category: 'elevated',
        color: 'yellow',
        message: 'Elevated heart rate',
      };
    }

    return {
      category: 'high',
      color: 'red',
      message: 'High heart rate',
    };
  };

  const heartRateInfo = getHeartRateCategory(heartRate);

  if (!isAvailable) {
    return (
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <div className="bg-primary-50 px-4 py-5 border-b border-gray-200 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Health Device Connection</h3>
          <p className="mt-1 text-sm text-gray-500">
            Connect to your heart rate monitor to track your vital signs.
          </p>
        </div>
        <div className="p-6">
          <div className="rounded-md bg-yellow-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-yellow-400" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-yellow-800">Browser Compatibility Issue</h3>
                <div className="mt-2 text-sm text-yellow-700">
                  <p>
                    Your browser doesn't support the Web Bluetooth API. Please use a compatible browser like Chrome, Edge, or Opera.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="bg-primary-50 px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Health Device Connection</h3>
        <p className="mt-1 text-sm text-gray-500">
          Connect to your heart rate monitor to track your vital signs.
        </p>
      </div>

      <div className="p-6">
        {error && (
          <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-red-400" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1">
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-lg font-medium text-gray-900">Heart Rate Monitor</h4>
                <div
                  className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    isConnected
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}
                >
                  <span
                    className={`h-2 w-2 mr-1 rounded-full ${
                      isConnected ? 'bg-green-400' : 'bg-gray-400'
                    }`}
                  ></span>
                  {isConnected ? 'Connected' : 'Disconnected'}
                </div>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div
                  className={`p-4 rounded-full ${
                    isConnected ? 'bg-primary-50' : 'bg-gray-100'
                  }`}
                >
                  <Bluetooth
                    className={`h-8 w-8 ${
                      isConnected ? 'text-primary-500' : 'text-gray-400'
                    }`}
                  />
                </div>
                <div>
                  <p className="text-sm text-gray-500">
                    {isConnected
                      ? 'Your heart rate monitor is connected and sending data.'
                      : 'Click the connect button to pair with your heart rate monitor.'}
                  </p>
                  <div className="mt-2">
                    {isConnected ? (
                      <button
                        onClick={disconnectDevice}
                        className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                      >
                        Disconnect Device
                      </button>
                    ) : (
                      <button
                        onClick={connectDevice}
                        className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                      >
                        Connect Device
                      </button>
                    )}
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <h5 className="text-sm font-medium text-gray-500 mb-2">Compatible Devices</h5>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li className="flex items-center">
                    <span className="h-1.5 w-1.5 rounded-full bg-gray-400 mr-2"></span>
                    Bluetooth Heart Rate Monitors
                  </li>
                  <li className="flex items-center">
                    <span className="h-1.5 w-1.5 rounded-full bg-gray-400 mr-2"></span>
                    Fitness Trackers with HR functionality
                  </li>
                  <li className="flex items-center">
                    <span className="h-1.5 w-1.5 rounded-full bg-gray-400 mr-2"></span>
                    Smart Watches with Bluetooth connectivity
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="flex-1">
            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200 h-full flex flex-col">
              <h4 className="text-lg font-medium text-gray-900 mb-4">Current Heart Rate</h4>

              {isConnected ? (
                <>
                  <div className="flex-1 flex flex-col items-center justify-center">
                    <div
                      className={`relative mb-4 w-32 h-32 rounded-full flex items-center justify-center ${
                        heartRate ? `bg-${heartRateInfo.color}-50` : 'bg-gray-50'
                      } border-4 ${
                        heartRate
                          ? `border-${heartRateInfo.color}-500`
                          : 'border-gray-200'
                      }`}
                    >
                      <Heart
                        className={`h-10 w-10 ${
                          heartRate ? `text-${heartRateInfo.color}-500` : 'text-gray-300'
                        } ${heartRate ? 'animate-pulse' : ''}`}
                      />
                      {heartRate && (
                        <div className="absolute -bottom-3 bg-white px-3 py-1 rounded-full border border-gray-200 shadow-sm">
                          <span className="text-lg font-bold">{heartRate}</span>
                          <span className="text-xs ml-1">BPM</span>
                        </div>
                      )}
                    </div>

                    <div className="text-center mt-4">
                      <p className="text-sm font-medium text-gray-900">
                        {heartRate ? heartRateInfo.message : 'Waiting for data...'}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {heartRate
                          ? 'Data updating in real-time'
                          : 'Make sure your device is properly worn'}
                      </p>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-gray-200">
                    <h5 className="text-sm font-medium mb-2">Heart Rate Zones</h5>
                    <div className="grid grid-cols-4 gap-1 text-xs text-center">
                      <div className="bg-blue-50 text-blue-700 p-1 rounded">
                        <span>Rest</span>
                        <p className="font-medium">&lt;60</p>
                      </div>
                      <div className="bg-green-50 text-green-700 p-1 rounded">
                        <span>Normal</span>
                        <p className="font-medium">60-100</p>
                      </div>
                      <div className="bg-yellow-50 text-yellow-700 p-1 rounded">
                        <span>Elevated</span>
                        <p className="font-medium">100-120</p>
                      </div>
                      <div className="bg-red-50 text-red-700 p-1 rounded">
                        <span>High</span>
                        <p className="font-medium">&gt;120</p>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center">
                  <Activity className="h-12 w-12 text-gray-300 mb-4" />
                  <p className="text-gray-500">
                    Connect your heart rate monitor to see your data here.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BluetoothDeviceMonitor;