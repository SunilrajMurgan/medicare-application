import React from 'react';
import NavBar from './NavBar';
import { useAuth } from '../../context/AuthContext';

interface PageContainerProps {
  children: React.ReactNode;
  title?: string;
}

const PageContainer: React.FC<PageContainerProps> = ({ children, title }) => {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar />
      
      <main className={`${user ? 'md:ml-64' : ''} min-h-screen`}>
        {title && (
          <header className="bg-white shadow-sm">
            <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
              <h1 className="text-xl font-semibold text-gray-900">{title}</h1>
            </div>
          </header>
        )}
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default PageContainer;