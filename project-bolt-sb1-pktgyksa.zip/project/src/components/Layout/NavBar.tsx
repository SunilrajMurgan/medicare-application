import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Heart, Calendar, MessageSquare, Home, UserCircle, LogOut, Menu, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

const NavBar: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const [isOpen, setIsOpen] = React.useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  if (!user) return null;

  return (
    <>
      {/* Mobile menu button */}
      <button 
        className="fixed right-4 top-4 z-50 md:hidden bg-white rounded-full p-2 shadow-md"
        onClick={toggleMenu}
        aria-label="Toggle menu"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar for desktop */}
      <aside className="hidden md:flex flex-col w-64 bg-white h-screen fixed left-0 top-0 shadow-md">
        <div className="flex items-center justify-center h-16 border-b">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="text-primary-600" size={24} />
            <span className="font-bold text-lg">MediCare</span>
          </Link>
        </div>
        
        <nav className="flex-1 py-4">
          <ul className="space-y-2 px-4">
            <li>
              <Link
                to="/"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Home size={20} />
                <span>Home</span>
              </Link>
            </li>
            <li>
              <Link
                to="/health-chat"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/health-chat') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <MessageSquare size={20} />
                <span>Health Chat</span>
              </Link>
            </li>
            <li>
              <Link
                to="/appointments"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/appointments') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Calendar size={20} />
                <span>Appointments</span>
              </Link>
            </li>
            <li>
              <Link
                to="/device-connect"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/device-connect') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Heart size={20} />
                <span>Health Devices</span>
              </Link>
            </li>
            <li>
              <Link
                to="/profile"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/profile') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <UserCircle size={20} />
                <span>Profile</span>
              </Link>
            </li>
          </ul>
        </nav>
        
        <div className="p-4 border-t">
          <button
            onClick={logout}
            className="flex items-center gap-3 w-full py-2 px-4 text-gray-700 hover:bg-gray-100 rounded-lg"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Mobile menu */}
      <div
        className={`fixed inset-0 bg-gray-800 bg-opacity-50 z-40 md:hidden transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={closeMenu}
      />

      <div
        className={`fixed inset-y-0 left-0 w-64 bg-white z-50 shadow-lg transform transition-transform duration-300 ease-in-out md:hidden ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-center h-16 border-b">
          <Link to="/" className="flex items-center gap-2" onClick={closeMenu}>
            <Heart className="text-primary-600" size={24} />
            <span className="font-bold text-lg">MediCare</span>
          </Link>
        </div>
        
        <nav className="flex-1 py-4">
          <ul className="space-y-2 px-4">
            <li>
              <Link
                to="/"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={closeMenu}
              >
                <Home size={20} />
                <span>Home</span>
              </Link>
            </li>
            <li>
              <Link
                to="/health-chat"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/health-chat') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={closeMenu}
              >
                <MessageSquare size={20} />
                <span>Health Chat</span>
              </Link>
            </li>
            <li>
              <Link
                to="/appointments"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/appointments') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={closeMenu}
              >
                <Calendar size={20} />
                <span>Appointments</span>
              </Link>
            </li>
            <li>
              <Link
                to="/device-connect"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/device-connect') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={closeMenu}
              >
                <Heart size={20} />
                <span>Health Devices</span>
              </Link>
            </li>
            <li>
              <Link
                to="/profile"
                className={`flex items-center gap-3 py-2 px-4 rounded-lg ${
                  isActive('/profile') ? 'bg-primary-50 text-primary-600' : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={closeMenu}
              >
                <UserCircle size={20} />
                <span>Profile</span>
              </Link>
            </li>
          </ul>
        </nav>
        
        <div className="p-4 border-t">
          <button
            onClick={() => { logout(); closeMenu(); }}
            className="flex items-center gap-3 w-full py-2 px-4 text-gray-700 hover:bg-gray-100 rounded-lg"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </>
  );
};

export default NavBar;