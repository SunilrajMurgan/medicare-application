import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Video, X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { getUserAppointments, cancelAppointment, Hospital, Doctor } from '../../services/appointmentService';
import { Appointment } from '../../types';

const AppointmentList: React.FC = () => {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAppointments = () => {
      if (user) {
        try {
          const userAppointments = getUserAppointments(user.id);
          setAppointments(userAppointments);
        } catch (err) {
          setError('Failed to load appointments');
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchAppointments();
  }, [user]);

  const handleCancelAppointment = async (appointmentId: string) => {
    if (confirm('Are you sure you want to cancel this appointment?')) {
      try {
        await cancelAppointment(appointmentId);
        setAppointments(appointments.map(appointment => 
          appointment.id === appointmentId ? { ...appointment, status: 'cancelled' } : appointment
        ));
      } catch (error) {
        setError('Failed to cancel appointment');
      }
    }
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (date: Date) => {
    return new Date(date).toLocaleTimeString(undefined, {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow p-6 text-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="bg-red-50 border-l-4 border-red-400 p-4">
          <div className="flex">
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="bg-primary-50 px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Your Appointments</h3>
        <p className="mt-1 text-sm text-gray-500">
          View and manage your upcoming and past appointments.
        </p>
      </div>

      {appointments.length === 0 ? (
        <div className="p-6 text-center">
          <p className="text-gray-500">You don't have any appointments yet.</p>
        </div>
      ) : (
        <ul className="divide-y divide-gray-200">
          {appointments.map((appointment) => (
            <li key={appointment.id} className="p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    {appointment.type === 'in-person' ? (
                      <MapPin className="h-5 w-5 text-gray-400 mr-2" />
                    ) : (
                      <Video className="h-5 w-5 text-gray-400 mr-2" />
                    )}
                    <span className="font-medium">
                      {appointment.type === 'in-person' ? 'In-person Visit' : 'Video Consultation'}
                    </span>
                    <span
                      className={`ml-3 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        appointment.status === 'scheduled'
                          ? 'bg-green-100 text-green-800'
                          : appointment.status === 'completed'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                    </span>
                  </div>

                  <div className="ml-7">
                    <div className="text-sm text-gray-500 flex items-center mb-1">
                      <Calendar className="h-4 w-4 mr-1" />
                      {formatDate(appointment.dateTime)}
                    </div>
                    <div className="text-sm text-gray-500 flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {formatTime(appointment.dateTime)}
                    </div>
                    {appointment.notes && (
                      <div className="mt-2 text-sm text-gray-500">
                        <p className="font-medium">Notes:</p>
                        <p>{appointment.notes}</p>
                      </div>
                    )}
                  </div>
                </div>

                {appointment.status === 'scheduled' && (
                  <div className="mt-4 md:mt-0">
                    <button
                      onClick={() => handleCancelAppointment(appointment.id)}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Cancel
                    </button>
                  </div>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AppointmentList;