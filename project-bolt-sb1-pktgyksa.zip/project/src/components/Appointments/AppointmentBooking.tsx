import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Video, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { 
  getHospitals, 
  getDoctorsByHospital, 
  bookAppointment, 
  Hospital, 
  Doctor 
} from '../../services/appointmentService';

const AppointmentBooking: React.FC = () => {
  const { user } = useAuth();
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [selectedHospital, setSelectedHospital] = useState<string>('');
  const [selectedDoctor, setSelectedDoctor] = useState<string>('');
  const [appointmentDate, setAppointmentDate] = useState<string>('');
  const [appointmentTime, setAppointmentTime] = useState<string>('');
  const [appointmentType, setAppointmentType] = useState<'in-person' | 'video'>('in-person');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const hospitalData = await getHospitals();
        setHospitals(hospitalData);
      } catch (error) {
        setError('Failed to load hospitals');
      }
    };

    fetchHospitals();
  }, []);

  useEffect(() => {
    const fetchDoctors = async () => {
      if (selectedHospital) {
        try {
          const doctorData = await getDoctorsByHospital(selectedHospital);
          setDoctors(doctorData);
          setSelectedDoctor('');
        } catch (error) {
          setError('Failed to load doctors');
        }
      } else {
        setDoctors([]);
      }
    };

    fetchDoctors();
  }, [selectedHospital]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!user) {
      setError('You must be logged in to book an appointment');
      return;
    }

    if (!selectedHospital || !selectedDoctor || !appointmentDate || !appointmentTime) {
      setError('Please fill in all required fields');
      return;
    }

    const dateTime = new Date(`${appointmentDate}T${appointmentTime}`);
    if (isNaN(dateTime.getTime())) {
      setError('Invalid date or time');
      return;
    }

    setIsLoading(true);

    try {
      await bookAppointment(
        user.id,
        selectedDoctor,
        selectedHospital,
        dateTime,
        appointmentType,
        notes
      );
      
      setSuccess('Appointment booked successfully!');
      // Reset form
      setSelectedDoctor('');
      setAppointmentDate('');
      setAppointmentTime('');
      setNotes('');
    } catch (error) {
      setError('Failed to book appointment. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="bg-primary-50 px-4 py-5 border-b border-gray-200 sm:px-6">
        <h3 className="text-lg leading-6 font-medium text-gray-900">Book an Appointment</h3>
        <p className="mt-1 text-sm text-gray-500">
          Schedule a consultation with one of our healthcare professionals.
        </p>
      </div>

      <div className="px-4 py-5 sm:p-6">
        {error && (
          <div className="mb-4 bg-red-50 border-l-4 border-red-400 p-4">
            <div className="flex">
              <div className="ml-3">
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
          </div>
        )}

        {success && (
          <div className="mb-4 bg-green-50 border-l-4 border-green-400 p-4">
            <div className="flex">
              <div className="ml-3">
                <p className="text-sm text-green-700">{success}</p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
            <div className="sm:col-span-3">
              <label htmlFor="hospital" className="block text-sm font-medium text-gray-700">
                Select Hospital
              </label>
              <div className="mt-1">
                <select
                  id="hospital"
                  name="hospital"
                  value={selectedHospital}
                  onChange={(e) => setSelectedHospital(e.target.value)}
                  className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                >
                  <option value="">Select a hospital</option>
                  {hospitals.map((hospital) => (
                    <option key={hospital.id} value={hospital.id}>
                      {hospital.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="doctor" className="block text-sm font-medium text-gray-700">
                Select Doctor
              </label>
              <div className="mt-1">
                <select
                  id="doctor"
                  name="doctor"
                  value={selectedDoctor}
                  onChange={(e) => setSelectedDoctor(e.target.value)}
                  disabled={!selectedHospital}
                  className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">Select a doctor</option>
                  {doctors.map((doctor) => (
                    <option key={doctor.id} value={doctor.id}>
                      Dr. {doctor.userId.split('-')[1].charAt(0).toUpperCase() + doctor.userId.split('-')[1].slice(1)} - {doctor.specialization}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                Appointment Date
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Calendar className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <input
                  type="date"
                  name="date"
                  id="date"
                  value={appointmentDate}
                  onChange={(e) => setAppointmentDate(e.target.value)}
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>

            <div className="sm:col-span-3">
              <label htmlFor="time" className="block text-sm font-medium text-gray-700">
                Appointment Time
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Clock className="h-5 w-5 text-gray-400" aria-hidden="true" />
                </div>
                <input
                  type="time"
                  name="time"
                  id="time"
                  value={appointmentTime}
                  onChange={(e) => setAppointmentTime(e.target.value)}
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                />
              </div>
            </div>

            <div className="sm:col-span-6">
              <label className="block text-sm font-medium text-gray-700">Appointment Type</label>
              <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div
                  className={`${
                    appointmentType === 'in-person'
                      ? 'bg-primary-50 border-primary-200'
                      : 'bg-white border-gray-200'
                  } border rounded-md p-4 cursor-pointer hover:bg-gray-50 transition-colors duration-150`}
                  onClick={() => setAppointmentType('in-person')}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`${
                        appointmentType === 'in-person' ? 'bg-primary-500' : 'bg-white border-2 border-gray-300'
                      } w-5 h-5 rounded-full flex items-center justify-center`}
                    >
                      {appointmentType === 'in-person' && (
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      )}
                    </div>
                    <div className="flex items-center">
                      <MapPin
                        className={`${
                          appointmentType === 'in-person' ? 'text-primary-600' : 'text-gray-400'
                        } h-5 w-5 mr-2`}
                      />
                      <span
                        className={`${
                          appointmentType === 'in-person' ? 'text-primary-900' : 'text-gray-500'
                        } text-sm font-medium`}
                      >
                        In-person Visit
                      </span>
                    </div>
                  </div>
                </div>

                <div
                  className={`${
                    appointmentType === 'video'
                      ? 'bg-primary-50 border-primary-200'
                      : 'bg-white border-gray-200'
                  } border rounded-md p-4 cursor-pointer hover:bg-gray-50 transition-colors duration-150`}
                  onClick={() => setAppointmentType('video')}
                >
                  <div className="flex items-center space-x-3">
                    <div
                      className={`${
                        appointmentType === 'video' ? 'bg-primary-500' : 'bg-white border-2 border-gray-300'
                      } w-5 h-5 rounded-full flex items-center justify-center`}
                    >
                      {appointmentType === 'video' && (
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      )}
                    </div>
                    <div className="flex items-center">
                      <Video
                        className={`${
                          appointmentType === 'video' ? 'text-primary-600' : 'text-gray-400'
                        } h-5 w-5 mr-2`}
                      />
                      <span
                        className={`${
                          appointmentType === 'video' ? 'text-primary-900' : 'text-gray-500'
                        } text-sm font-medium`}
                      >
                        Video Consultation
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="sm:col-span-6">
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Additional Notes
              </label>
              <div className="mt-1">
                <textarea
                  id="notes"
                  name="notes"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Briefly describe your symptoms or reason for the appointment"
                  className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border border-gray-300 rounded-md"
                ></textarea>
              </div>
            </div>
          </div>

          <div className="pt-5">
            <div className="flex justify-end">
              <button
                type="button"
                className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50"
              >
                {isLoading ? 'Booking...' : 'Book Appointment'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AppointmentBooking;