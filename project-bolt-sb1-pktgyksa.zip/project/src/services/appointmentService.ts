import { Appointment, Hospital, Doctor } from '../types';

// Mock hospitals data
const mockHospitals: Hospital[] = [
  {
    id: '1',
    name: 'City General Hospital',
    address: '123 Main St, Cityville',
    phone: '(555) 123-4567',
    specialties: ['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics']
  },
  {
    id: '2',
    name: 'Community Medical Center',
    address: '456 Oak Ave, Townsburg',
    phone: '(555) 987-6543',
    specialties: ['Family Medicine', 'Internal Medicine', 'Dermatology', 'Psychiatry']
  },
  {
    id: '3',
    name: 'Riverside Health Clinic',
    address: '789 River Rd, Riverside',
    phone: '(555) 765-4321',
    specialties: ['Obstetrics', 'Gynecology', 'Urology', 'Endocrinology']
  }
];

// Mock doctors data
const mockDoctors: Doctor[] = [
  {
    id: '1',
    userId: 'dr-smith',
    specialization: 'Cardiology',
    hospital: 'City General Hospital',
    availableDays: ['Monday', 'Tuesday', 'Thursday'],
    availableHours: [{ start: '09:00', end: '17:00' }]
  },
  {
    id: '2',
    userId: 'dr-johnson',
    specialization: 'Neurology',
    hospital: 'City General Hospital',
    availableDays: ['Wednesday', 'Friday'],
    availableHours: [{ start: '10:00', end: '18:00' }]
  },
  {
    id: '3',
    userId: 'dr-williams',
    specialization: 'Family Medicine',
    hospital: 'Community Medical Center',
    availableDays: ['Monday', 'Wednesday', 'Friday'],
    availableHours: [{ start: '08:00', end: '16:00' }]
  },
  {
    id: '4',
    userId: 'dr-brown',
    specialization: 'Dermatology',
    hospital: 'Community Medical Center',
    availableDays: ['Tuesday', 'Thursday'],
    availableHours: [{ start: '09:00', end: '17:00' }]
  },
  {
    id: '5',
    userId: 'dr-davis',
    specialization: 'Obstetrics',
    hospital: 'Riverside Health Clinic',
    availableDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    availableHours: [{ start: '08:00', end: '12:00' }, { start: '13:00', end: '17:00' }]
  }
];

// Function to get all hospitals
export const getHospitals = (): Promise<Hospital[]> => {
  return Promise.resolve(mockHospitals);
};

// Function to get doctors by hospital
export const getDoctorsByHospital = (hospitalId: string): Promise<Doctor[]> => {
  const hospital = mockHospitals.find(h => h.id === hospitalId);
  if (!hospital) return Promise.resolve([]);
  
  const doctors = mockDoctors.filter(d => d.hospital === hospital.name);
  return Promise.resolve(doctors);
};

// Function to get doctor by id
export const getDoctorById = (doctorId: string): Promise<Doctor | undefined> => {
  const doctor = mockDoctors.find(d => d.id === doctorId);
  return Promise.resolve(doctor);
};

// Function to book an appointment
export const bookAppointment = async (
  patientId: string,
  doctorId: string,
  hospitalId: string,
  dateTime: Date,
  type: 'in-person' | 'video',
  notes?: string
): Promise<Appointment> => {
  // This is a mock implementation - in a real app, you'd save to a database
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  const appointment: Appointment = {
    id: Date.now().toString(),
    patientId,
    doctorId,
    hospitalId,
    dateTime,
    status: 'scheduled',
    notes,
    type
  };
  
  // In a real app, save to database
  const savedAppointments = JSON.parse(localStorage.getItem('appointments') || '[]');
  savedAppointments.push(appointment);
  localStorage.setItem('appointments', JSON.stringify(savedAppointments));
  
  return appointment;
};

// Function to get user's appointments
export const getUserAppointments = (userId: string): Appointment[] => {
  const savedAppointments = JSON.parse(localStorage.getItem('appointments') || '[]');
  return savedAppointments.filter((appointment: Appointment) => 
    appointment.patientId === userId || appointment.doctorId === userId
  );
};

// Function to cancel an appointment
export const cancelAppointment = async (appointmentId: string): Promise<void> => {
  // This is a mock implementation - in a real app, you'd update a database
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  const savedAppointments = JSON.parse(localStorage.getItem('appointments') || '[]');
  const updatedAppointments = savedAppointments.map((appointment: Appointment) => {
    if (appointment.id === appointmentId) {
      return { ...appointment, status: 'cancelled' };
    }
    return appointment;
  });
  
  localStorage.setItem('appointments', JSON.stringify(updatedAppointments));
};