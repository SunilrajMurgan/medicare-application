import { HealthQuery } from '../types';

// Mock responses for different health conditions
const mockResponses: Record<string, string[]> = {
  fever: [
    "Based on your symptoms, it sounds like you might have a fever. It's important to rest, stay hydrated, and take over-the-counter fever reducers like acetaminophen if needed. If your temperature exceeds 103°F (39.4°C) or persists for more than three days, please contact a healthcare provider.",
    "Fevers are often a sign that your body is fighting an infection. Make sure to drink plenty of fluids, get adequate rest, and monitor your temperature. If you have severe symptoms or your fever doesn't improve after 72 hours, please seek medical attention."
  ],
  cold: [
    "Your symptoms suggest a common cold. The best treatment includes rest, staying hydrated, and taking over-the-counter cold medications for symptom relief. Most colds resolve within 7-10 days. If symptoms worsen significantly or don't improve after about a week, consult with a healthcare provider.",
    "For your cold symptoms, I recommend rest, plenty of fluids, and potentially over-the-counter decongestants or pain relievers for symptom management. Warm liquids like tea with honey may help soothe a sore throat. If you develop difficulty breathing, severe symptoms, or symptoms last longer than 10 days, please contact a healthcare provider."
  ],
  headache: [
    "For your headache, I recommend resting in a quiet, dark room, staying hydrated, and taking over-the-counter pain relievers such as ibuprofen or acetaminophen as directed. If your headache is severe, sudden, or accompanied by other concerning symptoms like confusion, stiff neck, or high fever, please seek immediate medical attention.",
    "Your headache symptoms might be relieved with rest, adequate hydration, and over-the-counter pain medication. Applying a cold or warm compress to your forehead or neck might also help. If you experience severe pain, headaches that wake you from sleep, or if the pattern of your headaches changes, please consult a healthcare provider."
  ]
};

// Function to get a health assistant response
export const getHealthAssistantResponse = async (query: string): Promise<string> => {
  // In a real implementation, this would connect to an AI service
  // This is a mock implementation that looks for keywords
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API delay
  
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('fever') || lowerQuery.includes('temperature') || lowerQuery.includes('hot')) {
    const responses = mockResponses.fever;
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  if (lowerQuery.includes('cold') || lowerQuery.includes('cough') || lowerQuery.includes('sneeze') || lowerQuery.includes('runny nose')) {
    const responses = mockResponses.cold;
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  if (lowerQuery.includes('headache') || lowerQuery.includes('head pain') || lowerQuery.includes('migraine')) {
    const responses = mockResponses.headache;
    return responses[Math.floor(Math.random() * responses.length)];
  }
  
  return "I'm sorry, I don't have enough information to provide specific advice about your health concern. For the best guidance, please consult with a healthcare professional who can evaluate your specific situation.";
};

// Function to save health queries
export const saveHealthQuery = async (query: string, category: HealthQuery['category'] = 'other', userId: string): Promise<HealthQuery> => {
  // This is a mock implementation - in a real app, you'd save to a database
  const response = await getHealthAssistantResponse(query);
  
  const healthQuery: HealthQuery = {
    id: Date.now().toString(),
    userId,
    question: query,
    answer: response,
    createdAt: new Date(),
    category
  };
  
  // In a real app, save to database
  const savedQueries = JSON.parse(localStorage.getItem('healthQueries') || '[]');
  savedQueries.push(healthQuery);
  localStorage.setItem('healthQueries', JSON.stringify(savedQueries));
  
  return healthQuery;
};

// Function to get a user's query history
export const getUserHealthQueries = (userId: string): HealthQuery[] => {
  const savedQueries = JSON.parse(localStorage.getItem('healthQueries') || '[]');
  return savedQueries.filter((query: HealthQuery) => query.userId === userId);
};