// Service for handling Bluetooth device connections

interface BluetoothDeviceState {
  device: BluetoothDevice | null;
  connected: boolean;
  heartRate: number | null;
  error: string | null;
}

class BluetoothService {
  private state: BluetoothDeviceState = {
    device: null,
    connected: false,
    heartRate: null,
    error: null
  };

  private listeners: Set<(state: BluetoothDeviceState) => void> = new Set();

  constructor() {
    // Check if Web Bluetooth API is available
    this.isAvailable = 'bluetooth' in navigator;
  }

  public isAvailable: boolean;

  // Add a state listener
  public subscribe(callback: (state: BluetoothDeviceState) => void) {
    this.listeners.add(callback);
    // Immediately call with current state
    callback({ ...this.state });
    
    // Return unsubscribe function
    return () => {
      this.listeners.delete(callback);
    };
  }

  // Update state and notify listeners
  private updateState(newState: Partial<BluetoothDeviceState>) {
    this.state = { ...this.state, ...newState };
    this.notifyListeners();
  }

  // Notify all listeners of state change
  private notifyListeners() {
    this.listeners.forEach(listener => listener({ ...this.state }));
  }

  // Connect to a heart rate monitor
  public async connectToHeartRateMonitor() {
    if (!this.isAvailable) {
      this.updateState({ 
        error: 'Web Bluetooth API is not available in your browser.' 
      });
      return;
    }

    try {
      // Request Bluetooth device with heart rate service
      const device = await navigator.bluetooth.requestDevice({
        filters: [{ services: ['heart_rate'] }]
      });

      this.updateState({ device, error: null });

      // Add event listener for when device gets disconnected
      device.addEventListener('gattserverdisconnected', () => {
        this.updateState({ connected: false });
      });

      // Connect to GATT server
      const server = await device.gatt?.connect();
      if (!server) {
        throw new Error('Failed to connect to GATT server');
      }

      // Get heart rate service
      const service = await server.getPrimaryService('heart_rate');
      
      // Get heart rate measurement characteristic
      const characteristic = await service.getCharacteristic('heart_rate_measurement');
      
      // Start notifications
      await characteristic.startNotifications();
      
      // Listen for heart rate measurement changes
      characteristic.addEventListener('characteristicvaluechanged', (event) => {
        const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
        if (value) {
          // The heart rate measurement value is in the 2nd byte
          const heartRate = value.getUint8(1);
          this.updateState({ heartRate });
        }
      });

      this.updateState({ connected: true });
    } catch (error) {
      this.updateState({ 
        error: error instanceof Error ? error.message : 'Failed to connect to device' 
      });
    }
  }

  // Disconnect from heart rate monitor
  public async disconnect() {
    if (this.state.device?.gatt?.connected) {
      await this.state.device.gatt.disconnect();
    }
    this.updateState({ 
      connected: false, 
      heartRate: null 
    });
  }
}

// Export a singleton instance
export const bluetoothService = new BluetoothService();