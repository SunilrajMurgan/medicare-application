import React from 'react';
import PageContainer from '../components/Layout/PageContainer';
import AppointmentBooking from '../components/Appointments/AppointmentBooking';
import AppointmentList from '../components/Appointments/AppointmentList';

const AppointmentsPage: React.FC = () => {
  return (
    <PageContainer title="Appointments">
      <div className="space-y-6">
        <AppointmentList />
        <AppointmentBooking />
      </div>
    </PageContainer>
  );
};

export default AppointmentsPage;