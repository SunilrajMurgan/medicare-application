import React from 'react';
import PageContainer from '../components/Layout/PageContainer';
import ChatInterface from '../components/HealthChat/ChatInterface';

const HealthChatPage: React.FC = () => {
  return (
    <PageContainer title="Health Assistant">
      <ChatInterface />
    </PageContainer>
  );
};

export default HealthChatPage;