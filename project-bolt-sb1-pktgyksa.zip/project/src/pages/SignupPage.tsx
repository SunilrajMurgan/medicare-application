import React from 'react';
import SignupForm from '../components/Auth/SignupForm';

const SignupPage: React.FC = () => {
  return <SignupForm />;
};

export default SignupPage;