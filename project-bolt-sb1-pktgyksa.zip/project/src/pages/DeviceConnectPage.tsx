import React from 'react';
import PageContainer from '../components/Layout/PageContainer';
import BluetoothDeviceMonitor from '../components/DeviceConnect/BluetoothDeviceMonitor';

const DeviceConnectPage: React.FC = () => {
  return (
    <PageContainer title="Health Devices">
      <BluetoothDeviceMonitor />
    </PageContainer>
  );
};

export default DeviceConnectPage;