import React from 'react';
import { Link } from 'react-router-dom';
import { MessageSquare, Calendar, Heart, ArrowRight } from 'lucide-react';
import PageContainer from '../components/Layout/PageContainer';
import { useAuth } from '../context/AuthContext';

const HomePage: React.FC = () => {
  const { user } = useAuth();

  return (
    <PageContainer>
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="bg-gradient-to-r from-primary-600 to-primary-500 px-6 py-12 md:py-20 md:px-10">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-2xl md:text-4xl font-bold text-white mb-4">
              Welcome{user ? `, ${user.name}` : ' to MediCare'}
            </h1>
            <p className="text-primary-50 text-lg md:text-xl mb-8">
              Your personal healthcare companion for smart health monitoring, 
              AI-powered assistance, and seamless doctor consultations.
            </p>
            {!user && (
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/signup"
                  className="inline-flex items-center justify-center bg-white text-primary-600 px-6 py-3 rounded-lg font-medium shadow-sm hover:bg-primary-50 transition-colors"
                >
                  Create account
                </Link>
                <Link
                  to="/login"
                  className="inline-flex items-center justify-center bg-primary-700 text-white px-6 py-3 rounded-lg font-medium shadow-sm hover:bg-primary-800 transition-colors"
                >
                  Sign in
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {user && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="bg-white p-6 rounded-lg shadow-md flex flex-col">
            <div className="bg-primary-50 p-3 rounded-full w-fit mb-4">
              <MessageSquare className="h-6 w-6 text-primary-600" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Health Assistant</h2>
            <p className="text-gray-600 mb-4 flex-grow">
              Get instant AI-powered responses for common health concerns like fever, cold, or headache.
            </p>
            <Link
              to="/health-chat"
              className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700 mt-2"
            >
              Ask a question <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md flex flex-col">
            <div className="bg-primary-50 p-3 rounded-full w-fit mb-4">
              <Calendar className="h-6 w-6 text-primary-600" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Appointments</h2>
            <p className="text-gray-600 mb-4 flex-grow">
              Schedule in-person or video consultations with healthcare professionals.
            </p>
            <Link
              to="/appointments"
              className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700 mt-2"
            >
              Book appointment <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md flex flex-col">
            <div className="bg-primary-50 p-3 rounded-full w-fit mb-4">
              <Heart className="h-6 w-6 text-primary-600" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Health Devices</h2>
            <p className="text-gray-600 mb-4 flex-grow">
              Connect your health monitoring devices via Bluetooth to track vital signs.
            </p>
            <Link
              to="/device-connect"
              className="inline-flex items-center text-primary-600 font-medium hover:text-primary-700 mt-2"
            >
              Connect devices <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      )}

      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="p-6">
          <h2 className="text-2xl font-semibold mb-6">How It Works</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary-50 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <MessageSquare className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">AI Health Assistant</h3>
              <p className="text-gray-600">
                Our AI-powered health assistant provides instant responses to your common health concerns, offering guidance and information.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary-50 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Calendar className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">Easy Appointments</h3>
              <p className="text-gray-600">
                Book appointments with healthcare professionals for both in-person visits and convenient video consultations.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary-50 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Heart className="h-8 w-8 text-primary-600" />
              </div>
              <h3 className="text-lg font-medium mb-2">Health Monitoring</h3>
              <p className="text-gray-600">
                Connect your smart health devices via Bluetooth to monitor and track your vital signs in real-time.
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 bg-gray-50 px-6 py-4">
          <p className="text-sm text-gray-500 text-center">
            This platform is for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
            Always seek the advice of your physician or other qualified health provider with any questions about your medical condition.
          </p>
        </div>
      </div>
    </PageContainer>
  );
};

export default HomePage;