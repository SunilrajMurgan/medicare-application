import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Mic, MicOff, Video, VideoOff, Phone } from 'lucide-react';
import PageContainer from '../components/Layout/PageContainer';
import { useAuth } from '../context/AuthContext';

const VideoCallPage: React.FC = () => {
  const { appointmentId } = useParams<{ appointmentId: string }>();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [isConnecting, setIsConnecting] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    // Mock connection delay
    const timer = setTimeout(() => {
      setIsConnecting(false);
      setIsConnected(true);
      
      // Start local video
      startLocalVideo();
      
      // Mock remote connection after a delay
      setTimeout(() => {
        if (remoteVideoRef.current) {
          // In a real app, this would use WebRTC to connect to the remote peer
          // For mock purposes, we're just showing a placeholder
          remoteVideoRef.current.poster = "https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg";
        }
      }, 2000);
    }, 3000);
    
    return () => {
      clearTimeout(timer);
      // Clean up video streams
      if (localVideoRef.current && localVideoRef.current.srcObject) {
        const stream = localVideoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [user, navigate]);
  
  const startLocalVideo = async () => {
    try {
      const constraints = { audio: true, video: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
    } catch (err) {
      setError('Could not access camera or microphone. Please check permissions.');
      console.error('Error accessing media devices:', err);
    }
  };
  
  const toggleMute = () => {
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream;
      stream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };
  
  const toggleVideo = () => {
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream;
      stream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };
  
  const endCall = () => {
    // Clean up video streams
    if (localVideoRef.current && localVideoRef.current.srcObject) {
      const stream = localVideoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    
    // Navigate back to appointments
    navigate('/appointments');
  };
  
  return (
    <PageContainer title="Video Consultation">
      <div className="bg-gray-900 rounded-lg shadow-lg overflow-hidden">
        {isConnecting && (
          <div className="flex flex-col items-center justify-center p-10 text-white h-96">
            <div className="animate-pulse flex flex-col items-center">
              <div className="rounded-full h-16 w-16 bg-primary-500 flex items-center justify-center mb-4">
                <Video className="h-8 w-8" />
              </div>
              <h2 className="text-xl font-semibold mb-2">Connecting to your appointment...</h2>
              <p className="text-gray-300">Please wait while we establish a secure connection</p>
            </div>
          </div>
        )}
        
        {error && (
          <div className="p-4 bg-red-500 text-white">
            <p>{error}</p>
          </div>
        )}
        
        {isConnected && (
          <div className="relative">
            {/* Remote video (doctor) - full size */}
            <div className="w-full h-[calc(100vh-14rem)] bg-gray-800">
              <video
                ref={remoteVideoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
              />
            </div>
            
            {/* Local video (patient) - small overlay */}
            <div className="absolute right-4 top-4 w-48 h-36 bg-gray-900 rounded-lg overflow-hidden shadow-lg border-2 border-gray-700">
              <video
                ref={localVideoRef}
                className="w-full h-full object-cover"
                autoPlay
                playsInline
                muted
              />
              
              {isVideoOff && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-70">
                  <Video className="h-8 w-8 text-red-500" />
                </div>
              )}
            </div>
            
            {/* Call controls */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-gray-900 to-transparent">
              <div className="flex justify-center space-x-4">
                <button
                  onClick={toggleMute}
                  className={`p-3 rounded-full ${
                    isMuted ? 'bg-red-500' : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                >
                  {isMuted ? (
                    <MicOff className="h-6 w-6 text-white" />
                  ) : (
                    <Mic className="h-6 w-6 text-white" />
                  )}
                </button>
                
                <button
                  onClick={toggleVideo}
                  className={`p-3 rounded-full ${
                    isVideoOff ? 'bg-red-500' : 'bg-gray-700 hover:bg-gray-600'
                  }`}
                >
                  {isVideoOff ? (
                    <VideoOff className="h-6 w-6 text-white" />
                  ) : (
                    <Video className="h-6 w-6 text-white" />
                  )}
                </button>
                
                <button
                  onClick={endCall}
                  className="p-3 rounded-full bg-red-600 hover:bg-red-700"
                >
                  <Phone className="h-6 w-6 text-white" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </PageContainer>
  );
};

export default VideoCallPage;