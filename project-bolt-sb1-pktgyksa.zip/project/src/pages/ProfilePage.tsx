import React from 'react';
import PageContainer from '../components/Layout/PageContainer';
import ProfileForm from '../components/Profile/ProfileForm';

const ProfilePage: React.FC = () => {
  return (
    <PageContainer title="Your Profile">
      <ProfileForm />
    </PageContainer>
  );
};

export default ProfilePage;