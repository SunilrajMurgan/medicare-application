export interface User {
  id: string;
  name: string;
  email: string;
  role: 'patient' | 'doctor' | 'admin';
  profileImage?: string;
}

export interface HealthQuery {
  id: string;
  userId: string;
  question: string;
  answer?: string;
  createdAt: Date;
  category: 'fever' | 'cold' | 'headache' | 'other';
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  hospitalId: string;
  dateTime: Date;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
  type: 'in-person' | 'video';
}

export interface Hospital {
  id: string;
  name: string;
  address: string;
  phone: string;
  specialties: string[];
}

export interface VitalReading {
  id: string;
  userId: string;
  type: 'heart-rate' | 'blood-pressure' | 'temperature' | 'oxygen';
  value: number;
  unit: string;
  timestamp: Date;
}

export interface Doctor {
  id: string;
  userId: string;
  specialization: string;
  hospital: string;
  availableDays: string[];
  availableHours: { start: string; end: string }[];
}